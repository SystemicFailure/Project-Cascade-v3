#!/usr/bin/env python3
"""
Daily news headline scan for CASCADE-RELEVANT EVENTS
Analysis driven by PROJECT GOALS
Early warning detection of infrastructure/system incidents

Frequency: Hourly at :24 minutes past each hour (UTC)
Note: Analysis tied to project goals, not fixed keywords
Note: Designed to run LOCALLY via Streamlit app "Run Now" button
"""

import sys
import subprocess
import os
import json
from datetime import datetime, timedelta

# Add cascade_app_package to path (contains the correct cascade_db with add_finding)
possible_paths = [
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cascade_app_package'),
    '/home/claude/cascade_updates/cascade_app_package',
    '/home/claude/confluence/cascade_app_package'
]
cascade_app_package_path = None
for path in possible_paths:
    if os.path.exists(os.path.join(path, 'cascade_db.py')):
        cascade_app_package_path = path
        break

if not cascade_app_package_path:
    print("[ERROR] cascade_app_package/cascade_db.py not found in any expected location")
    sys.exit(1)

sys.path.insert(0, cascade_app_package_path)

# Ensure requests is available
try:
    import requests
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "-q"])
    import requests

# Import cascade_db from cascade_app_package
try:
    from cascade_db import add_signal, add_finding, get_all_goals
except ImportError as e:
    print(f"[ERROR] Failed to import from cascade_db: {e}")
    print(f"[INFO] Searched in: {cascade_app_package_path}")
    print("[NOTE] This routine should be run from the Streamlit app 'Run Now' button")
    print("[NOTE] Ensure cascade_app_package/cascade_db.py exists with add_signal, add_finding, get_all_goals")
    sys.exit(1)

# ============================================
# NEWS SCANNING - GOAL-DRIVEN ANALYSIS
# ============================================

def try_scrape_article(url):
    """
    Attempt to scrape article content from URL
    Gracefully fall back to headline only if scraping blocked/fails
    """
    try:
        # Try beautifulsoup for web scraping (when allowed)
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4", "-q"])
            from bs4 import BeautifulSoup

        response = requests.get(url, timeout=5, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })

        if response.status_code == 200:
            soup = BeautifulSoup(response.content, 'html.parser')

            # Try to extract article body (common patterns)
            article_body = None
            for selector in ['article', '.article-body', '.entry-content', '.post-content', 'main']:
                body = soup.find(selector)
                if body:
                    article_body = body.get_text(separator=' ', strip=True)[:500]  # First 500 chars
                    break

            if article_body:
                return article_body
        return None

    except (requests.RequestException, Exception) as e:
        # Scraping blocked or failed - return None to use headline only
        return None

def extract_headlines_from_sources():
    """
    Extract articles and headlines from public news sources
    Strategy: Scrape when allowed, fallback to headlines when blocked
    Cross-reference across outlets for validation

    Sources accessed:
    - NewsAPI (headlines, metadata, outlet tracking)
    - RSS feeds (BBC, Reuters, AP, Guardian, NYT, etc.)
    - Direct article scraping (when site allows)
    - Returns: deduplicated stories with outlet count and first-source attribution
    """
    print("\n[NEWS] Extracting Articles/Headlines from Multi-Source News Feeds...")

    articles = []
    outlets_tracked = set()

    try:
        # Try NewsAPI if key available (fallback to free sources if not)
        news_api_key = os.environ.get('NEWS_API_KEY')

        if news_api_key:
            print("   [OK] NewsAPI key detected - fetching headlines")
            # Headlines only - no full article content
            url = "https://newsapi.org/v2/top-headlines"
            params = {
                'apiKey': news_api_key,
                'language': 'en',
                'pageSize': 100,
                'sortBy': 'publishedAt'
            }
            try:
                response = requests.get(url, params=params, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    for article in data.get('articles', []):
                        article_url = article['url']
                        # Try to scrape full content if available
                        scraped_content = try_scrape_article(article_url)

                        articles.append({
                            'title': article['title'],
                            'source': article['source']['name'],
                            'url': article_url,
                            'published': article['publishedAt'],
                            'description': article.get('description', ''),
                            'content': scraped_content,  # Full article if scraped
                            'scraped': scraped_content is not None
                        })
                        outlets_tracked.add(article['source']['name'])
            except Exception as e:
                print(f"   [WARNING] NewsAPI fetch failed: {e}")
        else:
            print("   [INFO] No NewsAPI key - using RSS feeds for headline extraction")
            # Fallback: RSS feeds (headlines only, no scraping)
            rss_feeds = {
                'BBC': 'http://feeds.bbc.co.uk/news/rss.xml',
                'Reuters': 'https://feeds.reuters.com/reuters/topNews',
                'AP': 'https://apnews.com/apf-sitemap/rss',
                'Guardian': 'https://www.theguardian.com/world/rss'
            }

            try:
                import feedparser
            except ImportError:
                subprocess.check_call([sys.executable, "-m", "pip", "install", "feedparser", "-q"])
                import feedparser

            for outlet_name, feed_url in rss_feeds.items():
                try:
                    feed = feedparser.parse(feed_url)
                    for entry in feed.entries[:20]:  # Last 20 headlines per feed
                        article_url = entry.get('link', '')
                        # Try to scrape full content when available
                        scraped_content = try_scrape_article(article_url) if article_url else None

                        articles.append({
                            'title': entry.get('title', ''),
                            'source': outlet_name,
                            'url': article_url,
                            'published': entry.get('published', ''),
                            'description': entry.get('summary', ''),
                            'content': scraped_content,  # Full article if scraped
                            'scraped': scraped_content is not None
                        })
                        outlets_tracked.add(outlet_name)
                except Exception as e:
                    print(f"   [WARNING] RSS feed error for {outlet_name}: {e}")

        scraped_count = sum(1 for a in articles if a['scraped'])
        print(f"   [OK] Extracted {len(articles)} articles from {len(outlets_tracked)} outlets ({scraped_count} scraped, {len(articles)-scraped_count} headlines-only)")
        return articles, outlets_tracked

    except Exception as e:
        print(f"   [WARNING] Headline extraction error: {e}")
        return [], outlets_tracked

def deduplicate_stories(articles):
    """
    Cross-reference same story across multiple outlets
    Returns: deduplicated stories with outlet count, first-source tracking, and best content

    Logic: If headline appears in 2+ outlets → validated signal
    Strategy: Use scraped content when available, fallback to description
    """
    print("   [INFO] Deduplicating stories across outlets...")

    deduplicated = {}
    story_outlets = {}

    for article in articles:
        # Simple dedup: check if similar headline already seen
        title_lower = article['title'].lower()

        # Find if this story already logged under different outlet
        found_match = False
        for existing_title in deduplicated.keys():
            # Check for keyword overlap (3+ common words = likely same story)
            existing_words = set(existing_title.lower().split())
            new_words = set(title_lower.split())
            overlap = len(existing_words & new_words)

            if overlap >= 3:  # Minimum keyword overlap for match
                story_outlets[existing_title].append({
                    'outlet': article['source'],
                    'url': article['url'],
                    'scraped': article['scraped']
                })
                # Keep the version with scraped content if available
                if article['scraped'] and not deduplicated[existing_title].get('content'):
                    deduplicated[existing_title] = article
                found_match = True
                break

        if not found_match:
            deduplicated[title_lower] = article
            story_outlets[title_lower] = [{
                'outlet': article['source'],
                'url': article['url'],
                'scraped': article['scraped']
            }]

    # Filter: only keep stories with 2+ outlet coverage (validated signals)
    validated = {}
    for title, first_article in deduplicated.items():
        if len(story_outlets[title]) >= 2:
            validated[title] = {
                'article': first_article,
                'outlets': story_outlets[title],
                'outlet_count': len(story_outlets[title]),
                'first_outlet': story_outlets[title][0]['outlet'],
                'scraped_count': sum(1 for o in story_outlets[title] if o['scraped'])
            }

    print(f"   [OK] Deduplicated to {len(validated)} multi-outlet stories")
    return validated

def generate_cascade_signals_from_goals():
    """
    Generate cascade signals from REAL news headlines
    Strategy: Extract headlines → deduplicate across outlets → map to goals

    Only signals with 2+ outlet coverage are validated (no single-source noise)
    """
    print("\n[NEWS] Scanning News Headlines for Cascade Events...")

    signals = []
    findings = []

    try:
        # Step 1: Extract headlines from multiple sources (headlines only, no scraping)
        headlines, outlets_tracked = extract_headlines_from_sources()

        if not headlines:
            print("   [WARNING] No headlines extracted")
            return signals, findings

        # Step 2: Deduplicate across outlets (only keep 2+ outlet stories)
        validated_stories = deduplicate_stories(headlines)

        if not validated_stories:
            print("   [WARNING] No multi-outlet story validation found")
        else:
            print(f"   [OK] {len(validated_stories)} validated stories from {len(outlets_tracked)} outlets")

        # Step 3: Load project goals and map stories to cascade nodes
        goals = get_all_goals()

        if not goals:
            print("   [WARNING] No project goals defined")
            return signals, findings

        print("   [STREAMS] Matching headlines against project goals...")

        # For each validated story, check if it matches any project goal
        for story_title, story_data in validated_stories.items():
            article = story_data['article']
            outlets = story_data['outlets']
            outlet_count = story_data['outlet_count']
            scraped_count = story_data['scraped_count']

            # Check against each goal for relevance
            for goal in goals:
                goal_text = goal['goal_text'].lower()
                title_text = article['title'].lower()
                description_text = (article['description'] or '').lower()
                content_text = (article.get('content') or '').lower()

                # Simple relevance check: keyword overlap (check all available text)
                goal_words = set(goal_text.split())
                title_words = set(title_text.split())
                description_words = set(description_text.split())
                content_words = set(content_text.split()) if content_text else set()

                overlap = len(goal_words & (title_words | description_words | content_words))

                if overlap >= 2:  # Minimum relevance threshold
                    # Determine cascade node from goal
                    if 'cascade' in goal_text or 'failure' in goal_text:
                        node_id = 0
                    elif 'infrastructure' in goal_text:
                        node_id = 6
                    elif 'bifurcation' in goal_text:
                        node_id = 11
                    elif 'geographic' in goal_text:
                        node_id = 12
                    elif 'monitor' in goal_text:
                        node_id = 6
                    else:
                        node_id = 0

                    # Create signal with outlet attribution and scrape status
                    outlet_list = ', '.join([o['outlet'] for o in outlets])
                    scrape_status = f" [{scraped_count}/{outlet_count} scraped]" if scraped_count > 0 else " [headlines]"
                    signal = {
                        'node': node_id,
                        'domain': f"News ({outlet_count} outlets{scrape_status}): {article['title'][:45]}",
                        'description': f"Outlets: {outlet_list}. Content: {article.get('content', article['description'])[:100]}... Goal: {goal['goal_text'][:50]}",
                        'severity': 'info' if outlet_count == 2 else 'warning',
                        'date': datetime.now().strftime('%Y-%m-%d'),
                        'source': f"Multi-outlet news aggregation ({outlet_list})"
                    }
                    signals.append(signal)
                    status = f" (scraped)" if article['scraped'] else " (headline)"
                    print(f"      [MATCH] {article['title'][:55]}...{status} ({outlet_count} outlets)")
                    break  # Only map to first matching goal

        # Create overall finding
        if signals:
            total_scraped = sum(1 for s in signals if '[scraped]' in s['domain'])
            total_headlines = len(signals) - total_scraped
            finding = {
                'mechanism': 'Multi-Outlet News Signal Detection',
                'text': f"Extracted articles from {len(outlets_tracked)} news outlets. Validated {len(signals)} signals with multi-outlet coverage (2+ outlets per story). Content analysis: {total_scraped} articles with scraped content, {total_headlines} headlines-only. Strategy: Scrape when allowed, fallback to headlines when blocked; deduplicate across sources for validation; extract signals through goal-relevance analysis.",
                'confidence': 0.75 if total_headlines > 0 else 0.85,  # Higher confidence when scraping
                'evidence': 'Cross-outlet aggregation, keyword-relevance matching to project goals, content analysis'
            }
            findings.append(finding)

        return signals, findings

    except Exception as e:
        print(f"   [WARNING] News monitoring error: {e}")
        import traceback
        traceback.print_exc()
        return signals, findings

def generate_report(signals, findings, signal_count, finding_count):
    """
    Generate structured report of findings and dashboard integration
    Logs: what was integrated, node mappings, cascade implications, data quality
    """
    print("\n" + "="*60)
    print("INTEGRATION REPORT: News Signal Processing")
    print("="*60 + "\n")

    if signal_count == 0 and finding_count == 0:
        print("[INFO] No new signals or findings to report")
        return

    # ============================================
    # SECTION 1: SIGNALS INTEGRATED
    # ============================================
    print("[SIGNALS INTEGRATED]")
    print(f"Total signals added: {signal_count}\n")

    # Group signals by node
    signals_by_node = {}
    for signal in signals:
        node_id = signal['node']
        if node_id not in signals_by_node:
            signals_by_node[node_id] = []
        signals_by_node[node_id].append(signal)

    node_names = {
        0: "Cascade Entry Point / Unclassified",
        6: "Measurement Capacity Erosion",
        11: "Infrastructure Built for Still Climate",
        12: "Adaptation Exhaustion / Geographic Bifurcation"
    }

    for node_id in sorted(signals_by_node.keys()):
        node_signals = signals_by_node[node_id]
        node_name = node_names.get(node_id, f"Node {node_id}")
        print(f"   Node {node_id} ({node_name}): {len(node_signals)} signals")

        for sig in node_signals:
            severity_badge = "🔴 CRITICAL" if sig['severity'] == 'critical' else \
                           "🟠 SERIOUS" if sig['severity'] == 'serious' else \
                           "🟡 WARNING" if sig['severity'] == 'warning' else "ℹ️  INFO"
            print(f"      {severity_badge}")
            print(f"      Domain: {sig['domain']}")
            print(f"      Source: {sig['source'][:70]}")
            print(f"      Description: {sig['description'][:80]}...")
            print()

    # ============================================
    # SECTION 2: FINDINGS INTEGRATED
    # ============================================
    print("[FINDINGS INTEGRATED]")
    print(f"Total findings added: {finding_count}\n")

    for i, finding in enumerate(findings, 1):
        confidence_pct = int(finding['confidence'] * 100)
        print(f"   Finding {i}: {finding['mechanism']}")
        print(f"      Confidence: {confidence_pct}%")
        print(f"      Evidence: {finding['evidence']}")
        print(f"      Summary: {finding['text'][:100]}...")
        print()

    # ============================================
    # SECTION 3: DASHBOARD INTEGRATION STATUS
    # ============================================
    print("[DASHBOARD INTEGRATION]")
    print("   ✓ Signals mapped to cascade nodes")
    print("   ✓ Findings added to Research Findings tab")
    print("   ✓ Multi-outlet validation applied (2+ outlet coverage)")
    print("   ✓ Goal-driven signal extraction complete")
    print("   ✓ Severity levels assigned for dashboard filtering")
    print()

    # ============================================
    # SECTION 4: DATA QUALITY METRICS
    # ============================================
    print("[DATA QUALITY METRICS]")
    print(f"   • Total signals processed: {len(signals)}")
    print(f"   • Signals with scraped content: [tracked in signal descriptions]")
    print(f"   • Multi-outlet validation: Applied")
    print(f"   • Goal alignment score: Keyword-based relevance matching")
    print(f"   • Cascade node coverage: {len(signals_by_node)} nodes represented")
    print()

    # ============================================
    # SECTION 5: NEXT ACTIONS FOR DASHBOARD
    # ============================================
    print("[DASHBOARD NEXT STEPS]")
    print("   1. View new signals in 'Granularity' tab → All Signals (Detailed View)")
    print("   2. Review findings in 'Research Findings' tab → Latest Entries")
    print("   3. Check cascade node activation in 'System Mechanism Tracker'")
    print("   4. Monitor signal severity distribution in 'Today's Progress' → Signal Distribution")
    print()

    # ============================================
    # SECTION 6: PERSISTENCE & ARCHIVAL
    # ============================================
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print("[ARCHIVAL]")
    print(f"   Timestamp: {timestamp}")
    print(f"   Database: Cascade_DB updated with {signal_count} signals, {finding_count} findings")
    print(f"   Status: ✓ COMMITTED TO DATABASE")
    print()

def main():
    print("\n" + "="*60)
    print("Daily News Headline Scan")
    print("="*60 + "\n")

    # Generate signals based on project goals
    signals, findings = generate_cascade_signals_from_goals()

    if not signals:
        print("\n[WARNING] No signals generated")
        return

    print(f"\n[PROCESSING] Processing {len(signals)} goal-aligned news streams...\n")

    signal_count = 0
    finding_count = 0

    # Add signals to database
    for signal in signals:
        try:
            add_signal(signal['node'], signal['domain'], signal['description'],
                      signal['severity'], signal['date'], signal['source'])
            print(f"   [OK] Signal: {signal['domain']}")
            signal_count += 1
        except Exception as e:
            print(f"   [WARNING] Error adding signal from {signal['domain']}: {e}")

    # Add findings to database
    for finding in findings:
        try:
            add_finding(finding['mechanism'], finding['text'],
                       finding['confidence'], finding['evidence'])
            print(f"   [OK] Finding: {finding['mechanism']}")
            finding_count += 1
        except Exception as e:
            print(f"   [WARNING] Error adding finding: {e}")

    print(f"\n[OK] Daily News Headline Scan Complete!")
    print(f"   - Signals added: {signal_count}")
    print(f"   - Findings added: {finding_count}")

    # Generate comprehensive integration report
    generate_report(signals, findings, signal_count, finding_count)

if __name__ == '__main__':
    main()
