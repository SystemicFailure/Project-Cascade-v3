# -*- coding: utf-8 -*-
"""
Project Cascade Database Schema and Operations
Standalone SQLite backend for cascade tracking
"""

import sqlite3
import json
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / 'cascade_data.db'

def init_db():
    """Initialize database with schema"""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Cascade Nodes
    c.execute('''CREATE TABLE IF NOT EXISTS cascade_nodes (
        node_id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        mechanism TEXT NOT NULL,
        status TEXT DEFAULT 'inactive',
        amplitude REAL DEFAULT 0,
        frequency REAL DEFAULT 0,
        confidence REAL DEFAULT 0,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Signals
    c.execute('''CREATE TABLE IF NOT EXISTS signals (
        signal_id INTEGER PRIMARY KEY,
        node_id INTEGER NOT NULL,
        domain TEXT,
        description TEXT,
        severity TEXT,
        date_recorded TIMESTAMP,
        source TEXT,
        status TEXT DEFAULT 'active',
        FOREIGN KEY(node_id) REFERENCES cascade_nodes(node_id)
    )''')

    # CASCADE Sequences
    c.execute('''CREATE TABLE IF NOT EXISTS cascade_sequences (
        cascade_id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        node_sequence TEXT,
        confidence REAL,
        description TEXT,
        verified_instances TEXT,
        date_identified TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # Reference Points
    c.execute('''CREATE TABLE IF NOT EXISTS reference_points (
        point_id INTEGER PRIMARY KEY,
        metric_name TEXT NOT NULL,
        value REAL,
        date_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        category TEXT
    )''')

    # Baseline Return Failures
    c.execute('''CREATE TABLE IF NOT EXISTS baseline_failures (
        failure_id INTEGER PRIMARY KEY,
        geography TEXT,
        sector TEXT,
        mechanism TEXT,
        baseline_shift_percent REAL,
        date_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        source TEXT
    )''')

    # Daily Summaries
    c.execute('''CREATE TABLE IF NOT EXISTS daily_summaries (
        summary_id INTEGER PRIMARY KEY,
        date TIMESTAMP NOT NULL UNIQUE,
        content TEXT,
        signals_count INTEGER,
        findings TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    conn.commit()
    conn.close()

def get_connection():
    """Get database connection"""
    return sqlite3.connect(DB_PATH)

def get_all_nodes():
    """Retrieve all cascade nodes"""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM cascade_nodes ORDER BY node_id')
    nodes = [dict(row) for row in c.fetchall()]
    conn.close()
    return nodes

def get_node_signals(node_id):
    """Get all signals for a node"""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM signals WHERE node_id = ? ORDER BY date_recorded DESC', (node_id,))
    signals = [dict(row) for row in c.fetchall()]
    conn.close()
    return signals

def get_all_signals(limit=None):
    """Retrieve all signals"""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    if limit:
        c.execute('SELECT * FROM signals ORDER BY date_recorded DESC LIMIT ?', (limit,))
    else:
        c.execute('SELECT * FROM signals ORDER BY date_recorded DESC')
    signals = [dict(row) for row in c.fetchall()]
    conn.close()
    return signals

def get_cascade_sequences():
    """Retrieve all CASCADE sequences"""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM cascade_sequences ORDER BY cascade_id')
    sequences = [dict(row) for row in c.fetchall()]
    conn.close()
    return sequences

def get_reference_points():
    """Retrieve reference point metrics"""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT DISTINCT metric_name, value, date_recorded FROM reference_points ORDER BY date_recorded DESC')
    points = [dict(row) for row in c.fetchall()]
    conn.close()
    return points

def get_baseline_failures():
    """Retrieve baseline return failures by geography/sector"""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM baseline_failures ORDER BY date_recorded DESC')
    failures = [dict(row) for row in c.fetchall()]
    conn.close()
    return failures

def get_daily_summary(date):
    """Get summary for specific date"""
    conn = get_connection()
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM daily_summaries WHERE DATE(date) = DATE(?)', (date,))
    summary = c.fetchone()
    conn.close()
    return dict(summary) if summary else None

def add_signal(node_id, domain, description, severity, date_recorded, source):
    """Add a signal"""
    conn = get_connection()
    c = conn.cursor()
    c.execute('''INSERT INTO signals (node_id, domain, description, severity, date_recorded, source)
                 VALUES (?, ?, ?, ?, ?, ?)''',
              (node_id, domain, description, severity, date_recorded, source))
    conn.commit()
    signal_id = c.lastrowid
    conn.close()
    return signal_id

def update_node_amplitude(node_id, amplitude):
    """Update node amplitude"""
    conn = get_connection()
    c = conn.cursor()
    c.execute('UPDATE cascade_nodes SET amplitude = ?, last_updated = CURRENT_TIMESTAMP WHERE node_id = ?',
              (amplitude, node_id))
    conn.commit()
    conn.close()

def update_node_frequency(node_id, frequency):
    """Update node frequency"""
    conn = get_connection()
    c = conn.cursor()
    c.execute('UPDATE cascade_nodes SET frequency = ?, last_updated = CURRENT_TIMESTAMP WHERE node_id = ?',
              (frequency, node_id))
    conn.commit()
    conn.close()

def get_metrics_summary():
    """Get summary metrics for dashboard"""
    conn = get_connection()
    c = conn.cursor()

    total_signals = c.execute('SELECT COUNT(*) FROM signals').fetchone()[0]
    active_nodes = c.execute('SELECT COUNT(*) FROM cascade_nodes WHERE status = "active"').fetchone()[0]
    cascade_sequences = c.execute('SELECT COUNT(*) FROM cascade_sequences').fetchone()[0]

    conn.close()

    return {
        'total_signals': total_signals,
        'active_nodes': active_nodes,
        'cascade_sequences': cascade_sequences
    }

if __name__ == '__main__':
    init_db()
    print(f"Database initialized at {DB_PATH}")
