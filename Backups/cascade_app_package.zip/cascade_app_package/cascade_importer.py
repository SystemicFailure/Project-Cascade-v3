# -*- coding: utf-8 -*-
"""
Data Importer - Parse existing markdown files and populate cascade_db
"""

import re
from datetime import datetime
from pathlib import Path
import sqlite3
from cascade_db import init_db, get_connection

CONFLUENCE_DIR = Path(__file__).parent

# Node definitions (13 nodes from Project Cascade)
NODES = {
    1: ("Water Bankruptcy", "Water system transition to scarcity-based management"),
    2: ("Regulatory Capture", "Exemptions retained rather than removed"),
    3: ("Institutional Suppression", "Change rejection via automatic denial mechanisms"),
    4: ("Rate of Change", "System change accelerating beyond adaptive capacity"),
    5: ("Thresholds Becoming Floors", "Disasters establish new lower baselines"),
    6: ("Measurement Capacity Erosion", "Inability to see/measure system degradation"),
    7: ("Economic Depletion", "Capital exhaustion from continuous crisis response"),
    8: ("Infrastructure Brittleness", "Built for stable climate, fails under change"),
    9: ("Scenario Planning Collapse", "Models only return 'solvable' pathways"),
    10: ("Coordination Cascade Failure", "System interdependencies amplify collapse"),
    11: ("Infrastructure Built for Still Climate", "Designed for historical conditions"),
    12: ("Adaptation Exhaustion", "Continuous change exhausts adaptive capacity"),
    13: ("Change/Adaptation Lag", "Systems optimize for past, not future"),
}

def import_cascade_nodes():
    """Initialize cascade nodes"""
    conn = get_connection()
    c = conn.cursor()

    for node_id, (name, mechanism) in NODES.items():
        c.execute('''INSERT OR IGNORE INTO cascade_nodes (node_id, name, mechanism, status)
                     VALUES (?, ?, ?, ?)''',
                  (node_id, name, mechanism, 'monitoring'))

    conn.commit()
    conn.close()
    print(f"✓ Imported {len(NODES)} cascade nodes")

def import_from_confluence_state():
    """Parse confluence_state.md for reference points and system state"""
    state_file = CONFLUENCE_DIR / 'confluence_state.md'

    if not state_file.exists():
        print("⚠ confluence_state.md not found")
        return

    content = state_file.read_text(encoding='utf-8')
    conn = get_connection()
    c = conn.cursor()

    # Extract reference points (look for patterns like "Amplitude 34" or "Frequency 44")
    ref_patterns = {
        'Amplitude': r'Amplitude[:\s]+(\d+)',
        'Frequency': r'Frequency[:\s]+(\d+)',
        'Interconnectedness': r'Interconnectedness[:\s]+(\d+)',
        'Systematic Underestimation': r'Systematic Underestimation[:\s]+(\d+)',
    }

    for metric, pattern in ref_patterns.items():
        matches = re.findall(pattern, content)
        if matches:
            value = float(matches[-1])  # Take the most recent value
            c.execute('''INSERT INTO reference_points (metric_name, value, category)
                         VALUES (?, ?, ?)''',
                      (metric, value, 'cascade_state'))

    conn.commit()
    conn.close()
    print("✓ Imported reference points from confluence_state.md")

def import_cascade_sequences():
    """Parse CASCADING_NODES_WATCH_LOG.md for CASCADE sequences"""
    watch_file = CONFLUENCE_DIR / 'CASCADING_NODES_WATCH_LOG.md'

    if not watch_file.exists():
        print("⚠ CASCADING_NODES_WATCH_LOG.md not found")
        return

    content = watch_file.read_text(encoding='utf-8')
    conn = get_connection()
    c = conn.cursor()

    # Parse CASCADE entries (CASCADE 1-12)
    cascade_pattern = r'\*\*CASCADE (\d+)[:\s]+.*?\(Node (\d+).*?→.*?Node (\d+)'
    cascades = re.findall(cascade_pattern, content, re.IGNORECASE)

    for cascade_num, node_a, node_b in cascades:
        cascade_id = int(cascade_num)
        node_sequence = f"{node_a}->{node_b}"

        # Extract confidence if available
        confidence_pattern = rf'CASCADE {cascade_num}.*?(?:confidence|confidence.*?|Confidence:.*?)(\d+)'
        conf_match = re.search(confidence_pattern, content, re.IGNORECASE | re.DOTALL)
        confidence = float(conf_match.group(1)) / 100 if conf_match else 0.75

        c.execute('''INSERT OR IGNORE INTO cascade_sequences
                     (cascade_id, name, node_sequence, confidence)
                     VALUES (?, ?, ?, ?)''',
                  (cascade_id, f"CASCADE {cascade_id}", node_sequence, confidence))

    conn.commit()
    conn.close()
    print(f"✓ Imported {len(cascades)} CASCADE sequences")

def import_baseline_failures():
    """Parse BASELINE_RETURN_FAILURE_RESEARCH_20260818.md"""
    baseline_file = CONFLUENCE_DIR / 'BASELINE_RETURN_FAILURE_RESEARCH_20260818.md'

    if not baseline_file.exists():
        print("⚠ Baseline failure research file not found")
        return

    content = baseline_file.read_text(encoding='utf-8')
    conn = get_connection()
    c = conn.cursor()

    # Extract baseline shifts (look for patterns like "Colorado River -33%")
    baseline_pattern = r'([A-Za-z\s]+)\s+(-?\d+)%'
    failures = re.findall(baseline_pattern, content)

    for location_or_sector, shift in failures[:20]:  # Limit to prevent duplicates
        location_or_sector = location_or_sector.strip()
        if location_or_sector and len(location_or_sector) > 3:
            c.execute('''INSERT INTO baseline_failures (geography, sector, mechanism, baseline_shift_percent)
                         VALUES (?, ?, ?, ?)''',
                      (location_or_sector, 'mixed', 'baseline_return_failure', float(shift)))

    conn.commit()
    conn.close()
    print(f"✓ Imported baseline return failure data")

def import_signals_from_new_index():
    """Parse new_index.html for signals (if accessible)"""
    # This would need HTML parsing - defer for now
    pass

def initialize_and_import():
    """Run all importers"""
    print("\n🚀 Starting Project Cascade Database Import...\n")

    init_db()
    print("✓ Database schema initialized")

    import_cascade_nodes()
    import_from_confluence_state()
    import_cascade_sequences()
    import_baseline_failures()

    print("\n✅ Import complete!")

    # Summary
    conn = get_connection()
    c = conn.cursor()

    nodes = c.execute('SELECT COUNT(*) FROM cascade_nodes').fetchone()[0]
    cascades = c.execute('SELECT COUNT(*) FROM cascade_sequences').fetchone()[0]
    baselines = c.execute('SELECT COUNT(*) FROM baseline_failures').fetchone()[0]
    ref_points = c.execute('SELECT COUNT(*) FROM reference_points').fetchone()[0]

    conn.close()

    print(f"\nDatabase Summary:")
    print(f"  • Cascade Nodes: {nodes}")
    print(f"  • CASCADE Sequences: {cascades}")
    print(f"  • Baseline Failures: {baselines}")
    print(f"  • Reference Points: {ref_points}")

if __name__ == '__main__':
    initialize_and_import()
