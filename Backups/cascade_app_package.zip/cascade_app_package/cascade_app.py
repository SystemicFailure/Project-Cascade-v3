# -*- coding: utf-8 -*-
"""
Project Cascade Standalone Application
Streamlit-based dashboard with 8 primary sections
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from cascade_db import (
    get_all_nodes, get_all_signals, get_cascade_sequences,
    get_reference_points, get_baseline_failures, get_metrics_summary,
    get_node_signals
)

# Page config
st.set_page_config(
    page_title="Project Cascade",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom theme
st.markdown("""
    <style>
    :root {
        --surface-1: #1a1a19;
        --text-primary: #ffffff;
        --text-secondary: #c3c2b7;
        --series-1: #3987e5;
    }
    body {
        background-color: #0d0d0d;
        color: #ffffff;
    }
    </style>
    """, unsafe_allow_html=True)

def metric_card(label, value, trend=None, color="#3987e5"):
    """Render a metric card"""
    col1, col2 = st.columns([3, 1])
    with col1:
        st.metric(label, value)
    if trend:
        with col2:
            st.caption(trend)

# ============================================
# 1. SUMMARY
# ============================================
def section_summary():
    st.header("📋 Summary")

    metrics = get_metrics_summary()
    nodes = get_all_nodes()
    active_nodes = [n for n in nodes if n['status'] == 'active']

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("Total Signals", metrics['total_signals'])
    with col2:
        st.metric("Active Nodes", len(active_nodes))
    with col3:
        st.metric("CASCADE Sequences", metrics['cascade_sequences'])
    with col4:
        ref_points = get_reference_points()
        latest_robustness = ref_points[0]['value'] if ref_points else 0
        st.metric("System Robustness", f"{latest_robustness:.0f}%")

    st.divider()

    # Active Nodes Table
    st.subheader("Active Cascade Nodes")
    if active_nodes:
        node_df = pd.DataFrame(active_nodes)
        node_df = node_df[['node_id', 'name', 'amplitude', 'frequency', 'confidence']]
        st.dataframe(node_df, use_container_width=True, hide_index=True)
    else:
        st.info("No active nodes currently being tracked")

    st.divider()

    # Recent Signals
    st.subheader("Recent Signals (Last 10)")
    signals = get_all_signals(limit=10)
    if signals:
        signals_df = pd.DataFrame(signals)
        signals_df['date_recorded'] = pd.to_datetime(signals_df['date_recorded'])
        st.dataframe(signals_df[['node_id', 'domain', 'severity', 'date_recorded']],
                     use_container_width=True, hide_index=True)
    else:
        st.info("No signals recorded yet")

# ============================================
# 2. TODAY'S PROGRESS
# ============================================
def section_today_progress():
    st.header("📈 Today's Progress")

    today = datetime.now().date()

    # Signal count by node (today vs historical)
    signals = get_all_signals()
    signals_df = pd.DataFrame(signals)

    if not signals_df.empty:
        signals_df['date'] = pd.to_datetime(signals_df['date_recorded']).dt.date
        today_signals = signals_df[signals_df['date'] == today]

        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Today's Signals", len(today_signals))
        with col2:
            st.metric("This Week's Signals", len(signals_df[signals_df['date'] >= today - timedelta(days=7)]))
        with col3:
            st.metric("Total Signals", len(signals_df))

        st.divider()

        # Signals by severity today
        if not today_signals.empty:
            st.subheader("Today's Signal Distribution")
            severity_counts = today_signals['severity'].value_counts()
            fig = px.bar(x=severity_counts.index, y=severity_counts.values,
                        labels={'x': 'Severity', 'y': 'Count'},
                        color=severity_counts.index,
                        color_discrete_map={'critical': '#d03b3b', 'serious': '#ec835a', 'warning': '#fab219'})
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No signals recorded for today yet")

        st.divider()

        # Trending nodes
        st.subheader("Active Nodes - Amplitude & Frequency")
        nodes = get_all_nodes()
        active_nodes = [n for n in nodes if n['status'] == 'active']

        if active_nodes:
            nodes_df = pd.DataFrame(active_nodes)
            fig = px.scatter(nodes_df, x='amplitude', y='frequency',
                           hover_name='name', size='confidence',
                           color='node_id',
                           title="Node Activation Landscape")
            st.plotly_chart(fig, use_container_width=True)

    else:
        st.info("No signal data available yet")

# ============================================
# 3. MISSION AND GOALS
# ============================================
def section_mission_goals():
    st.header("🎯 Mission and Goals")

    st.subheader("Framework")
    st.markdown("""
    **Project Cascade** tracks 13 mechanisms documenting how constrained systems fail sequentially.

    **13 Cascade Nodes:**
    1. Water Bankruptcy
    2. Regulatory Capture
    3. Institutional Suppression
    4. Rate of Change
    5. Thresholds Becoming Floors
    6. Measurement Capacity Erosion
    7. Economic Depletion
    8. Infrastructure Brittleness
    9. Scenario Planning Collapse
    10. Coordination Cascade Failure
    11. Infrastructure Built for Still Climate
    12. Adaptation Exhaustion
    13. Change/Adaptation Lag
    """)

    st.divider()

    st.subheader("Primary Goals")
    st.markdown("""
    1. **Systematic Observation** - Document cascade mechanism activation and amplification
    2. **Signal Integration** - Integrate research findings into framework without artificial delays
    3. **Baseline Return Tracking** - Monitor post-disaster recovery failures across sectors
    4. **Early Detection** - Identify cascade sequences before they lock in irreversibly
    5. **Real-time Monitoring** - Track amplitude, frequency, and interconnectedness metrics
    """)

    st.divider()

    st.subheader("Reference Points")
    ref_points = get_reference_points()
    if ref_points:
        # Get latest values for each metric
        metrics_latest = {}
        for rp in ref_points:
            metric = rp['metric_name']
            if metric not in metrics_latest or rp['date_recorded'] > metrics_latest[metric]['date_recorded']:
                metrics_latest[metric] = rp

        for metric, data in metrics_latest.items():
            st.metric(metric, f"{data['value']:.1f}")
    else:
        st.info("No reference points recorded yet")

# ============================================
# 4. AMPLITUDE
# ============================================
def section_amplitude():
    st.header("📊 Amplitude")

    st.subheader("Cascade Node Amplitude Levels")

    nodes = get_all_nodes()
    amplitude_data = [(n['node_id'], n['name'], n['amplitude']) for n in nodes if n['amplitude'] > 0]

    if amplitude_data:
        df = pd.DataFrame(amplitude_data, columns=['Node', 'Mechanism', 'Amplitude'])
        fig = px.bar(df, x='Mechanism', y='Amplitude',
                    color='Amplitude',
                    color_continuous_scale=['#199e70', '#fab219', '#ec835a', '#d03b3b'],
                    title="Cascade Node Amplitude (Escalation Magnitude)")
        fig.update_layout(height=500)
        st.plotly_chart(fig, use_container_width=True)

        st.divider()

        # Amplitude trends over time
        st.subheader("Reference Point Amplitude Trend")
        ref_points = get_reference_points()

        if ref_points:
            df_ref = pd.DataFrame(ref_points)
            df_ref['date_recorded'] = pd.to_datetime(df_ref['date_recorded'])
            df_ref = df_ref[df_ref['metric_name'] == 'Amplitude'].sort_values('date_recorded')

            if not df_ref.empty:
                fig = px.line(df_ref, x='date_recorded', y='value',
                             markers=True, title="Amplitude Trend")
                fig.update_xaxes(title_text="Date")
                fig.update_yaxes(title_text="Amplitude Value")
                st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No amplitude data available yet")

# ============================================
# 5. CASCADING NODES VISUALIZING
# ============================================
def section_cascading_nodes():
    st.header("🔗 Cascading Nodes Visualizing")

    st.subheader("CASCADE Sequences")

    sequences = get_cascade_sequences()

    if sequences:
        seq_df = pd.DataFrame(sequences)
        seq_df = seq_df[['cascade_id', 'name', 'node_sequence', 'confidence']]
        seq_df.columns = ['ID', 'Name', 'Node Chain', 'Confidence']
        st.dataframe(seq_df, use_container_width=True, hide_index=True)

        st.divider()

        st.subheader("Node Activation Matrix")

        nodes = get_all_nodes()

        # Create activation matrix
        node_grid = []
        for node in nodes:
            signals_for_node = get_node_signals(node['node_id'])
            node_grid.append({
                'Node': f"Node {node['node_id']}",
                'Mechanism': node['name'],
                'Status': node['status'].upper(),
                'Signals': len(signals_for_node),
                'Amplitude': node['amplitude'],
                'Frequency': node['frequency']
            })

        if node_grid:
            grid_df = pd.DataFrame(node_grid)
            st.dataframe(grid_df, use_container_width=True, hide_index=True)

            # Visualization
            st.subheader("Node Activity Heatmap")
            pivot_df = pd.DataFrame(node_grid).set_index('Node')[['Amplitude', 'Frequency']]

            fig = go.Figure(data=go.Heatmap(
                z=[pivot_df['Amplitude'].values, pivot_df['Frequency'].values],
                x=pivot_df.index,
                y=['Amplitude', 'Frequency'],
                colorscale='Reds',
                text=[[f"{v:.1f}" for v in pivot_df['Amplitude'].values],
                      [f"{v:.1f}" for v in pivot_df['Frequency'].values]],
                texttemplate="%{text}",
                textposition="middle center"
            ))
            fig.update_layout(title="Node Amplitude/Frequency Activation")
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No CASCADE sequences recorded yet")

# ============================================
# 6. SYSTEMATIC UNDERESTIMATION
# ============================================
def section_systematic_underestimation():
    st.header("⚠️ Systematic Underestimation")

    st.subheader("Definition")
    st.markdown("""
    Systematic underestimation occurs when metrics and monitoring systems fail to capture
    the true rate of system degradation, creating a persistent gap between measured change
    and actual change.
    """)

    ref_points = get_reference_points()

    if ref_points:
        df_ref = pd.DataFrame(ref_points)
        df_underest = df_ref[df_ref['metric_name'] == 'Systematic Underestimation'].sort_values('date_recorded')

        if not df_underest.empty:
            col1, col2 = st.columns(2)

            with col1:
                latest = df_underest.iloc[-1]
                st.metric("Latest Underestimation Index", f"{latest['value']:.1f}")

            with col2:
                st.metric("Recent Change", f"{latest['value'] - df_underest.iloc[-2]['value']:+.1f}")

            st.divider()

            st.subheader("Underestimation Trend")
            fig = px.line(df_underest, x='date_recorded', y='value',
                         markers=True, title="Systematic Underestimation Over Time")
            fig.update_xaxes(title_text="Date")
            fig.update_yaxes(title_text="Underestimation Index")
            st.plotly_chart(fig, use_container_width=True)

    else:
        st.info("No underestimation metrics recorded yet")

# ============================================
# 7. GRANULARITY
# ============================================
def section_granularity():
    st.header("🔬 Granularity")

    st.subheader("Signal Detail Breakdown")

    signals = get_all_signals()

    if signals:
        signals_df = pd.DataFrame(signals)

        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric("Total Signals", len(signals_df))
            st.metric("Unique Domains", signals_df['domain'].nunique())

        with col2:
            st.metric("Unique Severities", signals_df['severity'].nunique())
            st.metric("Unique Sources", signals_df['source'].nunique())

        with col3:
            active = signals_df[signals_df['status'] == 'active']
            st.metric("Active Signals", len(active))

        st.divider()

        st.subheader("Signals by Domain")

        domain_counts = signals_df['domain'].value_counts()
        fig = px.bar(x=domain_counts.index, y=domain_counts.values,
                    labels={'x': 'Domain', 'y': 'Signal Count'},
                    title="Signal Distribution by Domain")
        st.plotly_chart(fig, use_container_width=True)

        st.divider()

        st.subheader("Signals by Severity")

        severity_counts = signals_df['severity'].value_counts()
        fig = px.pie(values=severity_counts.values, names=severity_counts.index,
                    title="Severity Distribution")
        st.plotly_chart(fig, use_container_width=True)

        st.divider()

        st.subheader("All Signals (Detailed View)")
        st.dataframe(signals_df, use_container_width=True, hide_index=True)

    else:
        st.info("No signals recorded yet")

# ============================================
# 8. APPENDIX
# ============================================
def section_appendix():
    st.header("📚 Appendix")

    st.subheader("Baseline Return Failures")

    baseline_failures = get_baseline_failures()

    if baseline_failures:
        bf_df = pd.DataFrame(baseline_failures)
        bf_summary = bf_df.groupby('geography').agg({'baseline_shift_percent': 'first'}).reset_index()
        bf_summary.columns = ['Geography/Sector', 'Baseline Shift %']

        fig = px.bar(bf_summary, x='Geography/Sector', y='Baseline Shift %',
                    color='Baseline Shift %',
                    color_continuous_scale='Reds',
                    title="Baseline Return Failure by Geography")
        st.plotly_chart(fig, use_container_width=True)

        st.divider()

        st.subheader("Baseline Failure Details")
        st.dataframe(bf_df, use_container_width=True, hide_index=True)
    else:
        st.info("No baseline failure data recorded yet")

    st.divider()

    st.subheader("Data Schema")
    st.markdown("""
    **Project Cascade Database contains:**
    - **Cascade Nodes**: 13 primary mechanisms of system failure
    - **Signals**: Discrete observations of mechanism activation
    - **CASCADE Sequences**: Documented causal chains between nodes
    - **Reference Points**: Amplitude, Frequency, Interconnectedness, Underestimation
    - **Baseline Failures**: Geographic/sectoral baseline return patterns
    - **Daily Summaries**: Timestamped assessments and findings
    """)

# ============================================
# MAIN APP
# ============================================
def main():
    # Sidebar navigation
    with st.sidebar:
        st.title("Project Cascade")
        st.markdown("---")

        sections = [
            "Summary",
            "Today's Progress",
            "Mission and Goals",
            "Amplitude",
            "Cascading Nodes Visualizing",
            "Systematic Underestimation",
            "Granularity",
            "Appendix"
        ]

        selected = st.radio("Navigation", sections, label_visibility="collapsed")

    # Main content
    if selected == "Summary":
        section_summary()
    elif selected == "Today's Progress":
        section_today_progress()
    elif selected == "Mission and Goals":
        section_mission_goals()
    elif selected == "Amplitude":
        section_amplitude()
    elif selected == "Cascading Nodes Visualizing":
        section_cascading_nodes()
    elif selected == "Systematic Underestimation":
        section_systematic_underestimation()
    elif selected == "Granularity":
        section_granularity()
    elif selected == "Appendix":
        section_appendix()

    # Footer
    st.divider()
    st.caption(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == '__main__':
    main()
